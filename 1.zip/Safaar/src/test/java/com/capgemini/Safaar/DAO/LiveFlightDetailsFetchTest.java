package com.capgemini.Safaar.DAO;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;

public class LiveFlightDetailsFetchTest {
	
	
	
	@Test(expected=org.mockito.exceptions.misusing.MissingMethodInvocationException.class)
	public void getFlightsTest() {
	mock(LiveFlightDetailsFetch.class);
	when(((Object) LiveFlightDetailsFetch.getFlights("CCU", "BLR", "20181003"))).thenThrow(new org.mockito.exceptions.misusing.MissingMethodInvocationException(null));

	
	}

}
