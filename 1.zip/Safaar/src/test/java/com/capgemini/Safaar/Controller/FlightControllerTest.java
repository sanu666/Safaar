package com.capgemini.Safaar.Controller;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import com.capgemini.Safaar.controller.FlightController;

@RunWith(MockitoJUnitRunner.class)
public class FlightControllerTest {
	
	@InjectMocks
	FlightController flightsController;
	@Test(expected=org.mockito.exceptions.misusing.MissingMethodInvocationException.class)
	public void getFlightsControllerTest() throws JSONException
	{
		 Mockito.when(flightsController.getFlightDetails("CCU","BLR","2018103")).thenThrow(new JSONException(""));
		 
		
	}
	
	

}
