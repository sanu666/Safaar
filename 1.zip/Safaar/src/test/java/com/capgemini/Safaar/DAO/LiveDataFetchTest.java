package com.capgemini.Safaar.DAO;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.json.JSONException;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.junit.MockitoJUnitRunner;

import java.io.IOException;
@RunWith(MockitoJUnitRunner.class)
public class LiveDataFetchTest {
	@Test(expected=java.net.MalformedURLException.class)
public void readJsonFromUrlTestVer_2() throws IOException, JSONException
{
	mock(LiveDataFetch.class);
	
		when(LiveDataFetch.readJsonFromUrl("")).thenThrow(new org.mockito.exceptions.misusing.MissingMethodInvocationException(null));
		
	
	
}
@Test(expected=NullPointerException.class)
public void readAllTest() throws IOException
{
	mock(LiveDataFetch.class);
	
		when(LiveDataFetch.readAll(null)).thenReturn(null);
		
		
	
	
}
	
}
