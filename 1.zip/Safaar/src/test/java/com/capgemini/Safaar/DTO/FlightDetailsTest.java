package com.capgemini.Safaar.DTO;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;


import org.junit.Test;
import com.capgemini.Safaar.DTO.FlightsDetails;
public class FlightDetailsTest {
	
	FlightsDetails flight=new FlightsDetails();
	@Test
	public void testDefaultConstructor()
	{
		assertNotNull(flight);
	}
	
	@Test
	public void testParameterizedConstructor()
	{
		FlightsDetails flight=new FlightsDetails("kol","blr",null, null, null, null, null, null, null);
		assertNotNull(flight);	}
	
	@Test
	public void testSourceVer_1()
	{
		
		flight.setSource("CCU");
		assertEquals("CCU",flight.getSource());
	}
	
	@Test
	public void testSourceVer_2()
	{
		flight.setSource("2256bkjh");
		assertEquals("2256bkjh",flight.getSource());		
	}
	@Test
	public void testSourceVer_3()
	{
		flight.setSource(null);
		assertEquals(null,flight.getSource());		
	}
	
	@Test
	public void testDestVer_1()
	{
		
		flight.setDestination("BLR");
		assertEquals("BLR",flight.getDestination());
	}
	
	@Test
	public void testDestVer_2()
	{
		flight.setDestination("2256bkjh");
		assertEquals("2256bkjh",flight.getDestination());		
	}
	@Test
	public void testDestVer_3()
	{
		flight.setDestination(null);
		assertEquals(null,flight.getDestination());		
	}
	@Test
	public void testArrivalVer_1()
	{
		flight.setArrivalDateTime("20181003");
		assertEquals("20181003",flight.getArrivalDateTime());
	}
	@Test
	public void testArrivalVer_2()
	{
		flight.setArrivalDateTime(null);
		assertEquals(null,flight.getArrivalDateTime());
	}
	
	@Test
	public void testDepartVer_1()
	{
		flight.setDepDateTime("20181004");
		assertEquals("20181004",flight.getDepDateTime());
	}
	@Test
	public void testDepartVer_2()
	{
		flight.setDepDateTime(null);
		assertEquals(null,flight.getDepDateTime());
	}
	
	@Test
	public void testFlightCodeVer_1()
	{
		flight.setFlightCode("IXAI");
		assertEquals("IXAI",flight.getFlightCode());
	}
	@Test
	public void testFlightCodeVer_2()
	{
		flight.setFlightCode(null);
		assertEquals(null,flight.getFlightCode());
	}
	@Test
	public void testFlightNameVer_1()
	{
		flight.setFlightName("Air India");
		assertEquals("Air India",flight.getFlightName());
	}
	@Test
	public void testFlightNameVer_2()
	{
		flight.setFlightName(null);
		assertEquals(null,flight.getFlightName());
	}
	
	@Test
	public void testFlightDurationVer_1()
	{
		flight.setFlightDuration("2h55m");
		assertEquals("2h55m",flight.getFlightDuration());
	}
	@Test
	public void testFlightDurationVer_2()
	{
		flight.setFlightDuration(null);
		assertEquals(null,flight.getFlightDuration());
	}
	@Test
	public void testFareVer_1()
	{
		flight.setFare("5000");
		assertEquals("5000",flight.getFare());
	}
	@Test
	public void testFareVer_2()
	{
		flight.setFare(null);
		assertEquals(null,flight.getFare());
	}
	@Test
	public void testSeatingClass_1()
	{
		flight.setSeatingClass("B");
		assertEquals("B",flight.getSeatingClass());
	}
	@Test
	public void testSeatingClass_2()
	{
		flight.setSeatingClass(null);
		assertEquals(null,flight.getSeatingClass());
	}
	
	@Test
	public void testToString()
	{
		FlightsDetails flight=new FlightsDetails("kol","blr",null, null, null, null, null, null, null);
		assertNotNull(flight.toString());
	}

}
