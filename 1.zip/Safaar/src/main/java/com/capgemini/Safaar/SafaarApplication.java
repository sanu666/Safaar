package com.capgemini.Safaar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SafaarApplication {

	public static void main(String[] args) {
		SpringApplication.run(SafaarApplication.class, args);
	}
}
