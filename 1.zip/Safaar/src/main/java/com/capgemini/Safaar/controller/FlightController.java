package com.capgemini.Safaar.controller;
import java.util.ArrayList;

import org.json.JSONException;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.capgemini.Safaar.DAO.LiveFlightDetailsFetch;
import com.capgemini.Safaar.DTO.FlightsDetails;
@RestController
public class FlightController {
	/*@RequestMapping(value="/home2",method = RequestMethod.GET)
    public ModelAndView getFlightDetails() throws JSONException {
        ModelAndView model = new ModelAndView();    
        model.addObject("users",LiveFlightDetailsFetch.getAllFlights("CCU", "BLR", "20181006"));
        
        model.setViewName("index");
        return model;
        //return "hello";
    }
	@RequestMapping(value="/home1",method = RequestMethod.GET)
    public ArrayList<FlightsDetails> getFlightDetails1() throws JSONException {        
        ArrayList<FlightsDetails> x=LiveFlightDetailsFetch.getAllFlights("CCU", "BLR", "20181006");
        return x;
        //return "hello";
    }*/
	
	@RequestMapping(value="/home",method = RequestMethod.GET)
    public ArrayList<FlightsDetails> getFlightDetails(              @RequestParam(value="source") String source,
            @RequestParam(value="destination") String destination,
            @RequestParam(value="dateOfJourney") String dateOfJourney
) throws JSONException {        
        ArrayList<FlightsDetails> x=LiveFlightDetailsFetch.getAllFlights(source, destination, dateOfJourney);
        return x;
        //return "hello";
    }
	
}