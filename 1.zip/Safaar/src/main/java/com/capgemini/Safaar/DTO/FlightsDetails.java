package com.capgemini.Safaar.DTO;

import org.springframework.stereotype.Component;


@Component
public class FlightsDetails {
	
	private String source;
	private String destination;
	private String flightCode;
	private String flightName;
	private String flightDuration;
	private String seatingClass;
	private String arrivalDateTime;
	private String depDateTime;
	private String fare;

	public FlightsDetails() {
		
	}
	public String getFare() {
		return fare;
	}
	
	public void setFare(String fare) {
		this.fare = fare;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	public String getFlightCode() {
		return flightCode;
	}
	public void setFlightCode(String flightCode) {
		this.flightCode = flightCode;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getFlightDuration() {
		return flightDuration;
	}
	public void setFlightDuration(String flightDuration) {
		this.flightDuration = flightDuration;
	}
	public String getSeatingClass() {
		return seatingClass;
	}
	public void setSeatingClass(String seatingClass) {
		this.seatingClass = seatingClass;
	}
	public String getArrivalDateTime() {
		return arrivalDateTime;
	}
	public void setArrivalDateTime(String arrivalDateTime) {
		this.arrivalDateTime = arrivalDateTime;
	}
	public String getDepDateTime() {
		return depDateTime;
	}
	public void setDepDateTime(String depDateTime) {
		this.depDateTime = depDateTime;
	}
	public FlightsDetails(String source, String destination,String flightCode, String flightName,String flightDuration, String seatingClass, String arrivalDateTime,String depDateTime, String fare) {
		super();
		this.source = source;
		this.destination = destination;
		this.flightCode = flightCode;
		this.flightName = flightName;
		this.flightDuration = flightDuration;
		this.seatingClass = seatingClass;
		this.arrivalDateTime = arrivalDateTime;
		this.depDateTime = depDateTime;
		this.fare = fare;
	}
	@Override
	public String toString() {
		return "FlightsDetails [source=" + source + ", destination="
				+ destination + ", flightCode="
				+ flightCode + ", flightName=" + flightName
				+ ", flightDuration=" + flightDuration + ", seatingClass="
				+ seatingClass + ", arrivalDateTime=" + arrivalDateTime
				+ ", depDateTime=" + depDateTime + ", fare=" + fare + "]";
	}
	
	

}
