package com.capgemini.BusBooking.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BusBooking.DAO.BusBookingDAO;
import com.capgemini.BusBooking.DTO.BookingDetails;




@RestController
public class BusBookingController {
	@Autowired
	BusBookingDAO ob1;
	
	@RequestMapping(value="/book/bus",method = RequestMethod.GET)
    public String bookFlight() {  
		  BookingDetails ob=new BookingDetails();
	        ob.setAddress("jhghj");
	        ob.setBustype("kj");
	        ob.setBusname("sd");
	        ob.setDate("sd");
	        ob.setDestination("sad");
	        ob.setEmailId("abc");
	        ob.setFare("200");
	        ob.setNumberOfSeats("56");
	        ob.setPhoneNo("9053321");
	        ob.setSource("658");
	        ob.setNumberOfSeats("35");
	        System.out.println("controller");
	     
	        ob1.saveBookingDetails(ob);
	        //BookingDetailsDAO.find();
	        return "done";
	    }
	}