package com.capgemini.BusBooking.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BusBooking.DTO.BookingDetails;
import com.capgemini.BusBooking.Repository.BusBookingRepository;



@Service
public class BusBookingDAO {
	
	@Autowired
	public BusBookingRepository busDetailBook;
	
	public BookingDetails saveBookingDetails(BookingDetails book)
	{
		System.out.println("service");
		return busDetailBook.save(book);
		
	}
}