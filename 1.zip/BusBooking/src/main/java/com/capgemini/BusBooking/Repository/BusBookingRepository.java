package com.capgemini.BusBooking.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;

import com.capgemini.BusBooking.DTO.BookingDetails;
@Component
public interface BusBookingRepository extends MongoRepository<BookingDetails,String>  {

}
