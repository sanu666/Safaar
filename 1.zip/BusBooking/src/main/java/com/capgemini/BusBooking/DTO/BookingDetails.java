package com.capgemini.BusBooking.DTO;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection="bookBus")
public class BookingDetails {
	
	private String name;
	private String address;
	@Id
	private String emailId;
	private String phoneNo;
	private String source;
	private String destination;
	private String date;
	private String busname;
	private String bustype;
	private String NumberOfSeats;
	private String fare;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getBusname() {
		return busname;
	}
	public void setBusname(String busname) {
		this.busname = busname;
	}
	public String getBustype() {
		return bustype;
	}
	public void setBustype(String bustype) {
		this.bustype = bustype;
	}
	public String getNumberOfSeats() {
		return NumberOfSeats;
	}
	public void setNumberOfSeats(String numberOfSeats) {
		NumberOfSeats = numberOfSeats;
	}
	public String getFare() {
		return fare;
	}
	public void setFare(String fare) {
		this.fare = fare;
	}
	public BookingDetails(String name, String address, String emailId, String phoneNo, String source,
			String destination, String date, String busname, String bustype, String numberOfSeats, String fare) {
		super();
		this.name = name;
		this.address = address;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.source = source;
		this.destination = destination;
		this.date = date;
		this.busname = busname;
		this.bustype = bustype;
		NumberOfSeats = numberOfSeats;
		this.fare = fare;
	}
	public BookingDetails() {
		super();
	}
	@Override
	public String toString() {
		return "BookingDetails [name=" + name + ", address=" + address + ", emailId=" + emailId + ", phoneNo=" + phoneNo
				+ ", source=" + source + ", destination=" + destination + ", date=" + date + ", busname=" + busname
				+ ", bustype=" + bustype + ", NumberOfSeats=" + NumberOfSeats + ", fare=" + fare + "]";
	}
	
	
	
	
}

	