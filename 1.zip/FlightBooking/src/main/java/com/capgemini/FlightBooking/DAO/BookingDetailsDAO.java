package com.capgemini.FlightBooking.DAO;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.FlightBooking.DTO.BookingDetails;
import com.capgemini.FlightBooking.Repository.FlightDetailsBooking;

@Service
public class BookingDetailsDAO {
	
	@Autowired
	public FlightDetailsBooking flightDetailsBook;
	
	public BookingDetails saveBookingDetails(BookingDetails book)
	{
		System.out.println("service");
		return flightDetailsBook.save(book);
		
	}
	/*public static List<BookingDetails> find()
	{
		return flightDetailsBook.findAll();
	}*/

}
