package com.capgemini.FlightBooking.Controller;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.FlightBooking.DAO.BookingDetailsDAO;
import com.capgemini.FlightBooking.DTO.BookingDetails;



@RestController
public class FlightBookingController {
	@Autowired
	BookingDetailsDAO ob1;
	
	@RequestMapping(value="/book",method = RequestMethod.GET)
    public String bookFlight() {        
        BookingDetails ob=new BookingDetails();
        ob.setAddress("jhghj");
        ob.setAirClassOfTravel("kj");
        ob.setAirline("sd");
        ob.setDate("sd");
        ob.setDestination("sad");
        ob.setEmailId("abc");
        ob.setFare("200");
        ob.setNumberOfSeats("56");
        ob.setPhoneNo("9053321");
        ob.setSource("658");
        ob.setNumberOfSeats("35");
        System.out.println("controller");
     
        ob1.saveBookingDetails(ob);
        //BookingDetailsDAO.find();
        return "done";
    }

}
