package com.capgemini.FlightBooking.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Component;

import com.capgemini.FlightBooking.DTO.BookingDetails;
@Component
public interface FlightDetailsBooking extends MongoRepository<BookingDetails,String> {

}
