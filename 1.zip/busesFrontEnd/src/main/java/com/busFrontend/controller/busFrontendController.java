package com.busFrontend.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.ModelAndView;

import com.busFrontend.DTO.BusDetails;



@RestController
public class busFrontendController {
	
	@RequestMapping(value="/home", method=RequestMethod.GET)
	public ModelAndView homePage()
	{
		return new ModelAndView("index");
	}
	
	@RequestMapping(method=RequestMethod.POST)
	public ModelAndView listOfBuses(
			@RequestParam(value="source") String source,
            @RequestParam(value="destination") String destination,
            @RequestParam(value="dateOfJourney") String dateOfJourney
            ){
	System.out.println(source+" "+destination+" "+dateOfJourney);
	/*final String uri = "http://localhost:8066/home?source="+source+"&destination="+destination+"&dateOfJourney="+dateOfJourney+"";
	RestTemplate restTemplate = new RestTemplate();
	@SuppressWarnings("unchecked")
	List<BusDetails> list=restTemplate.getForObject(uri, ArrayList.class);
	return list;*/
	return new ModelAndView("index1");
	}

}
